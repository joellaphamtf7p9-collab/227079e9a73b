# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(tlsResume src/tlsResume.cpp)
set_property(TARGET tlsResume PROPERTY CXX_STANDARD 11)
target_link_libraries(tlsResume lionss pthread)

add_executable(HaskellStrictness src/HaskellStrictness.cpp)
set_property(TARGET HaskellStrictness PROPERTY CXX_STANDARD 11)
target_link_libraries(HaskellStrictness lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(rtcpFeedback src/rtcpFeedback.cpp)
set_property(TARGET rtcpFeedback PROPERTY CXX_STANDARD 11)
target_link_libraries(rtcpFeedback lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(clickhouse_merge src/clickhouse_merge.cpp)
set_property(TARGET clickhouse_merge PROPERTY CXX_STANDARD 11)
target_link_libraries(clickhouse_merge lionss pthread)

add_executable(FastqcTrim src/FastqcTrim.cpp)
set_property(TARGET FastqcTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(FastqcTrim lionss pthread)

add_executable(deopt-guard src/deopt-guard.cpp)
set_property(TARGET deopt-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(deopt-guard lionss pthread)

add_executable(reedmace src/reedmace.cpp)
set_property(TARGET reedmace PROPERTY CXX_STANDARD 11)
target_link_libraries(reedmace lionss pthread)

add_executable(quic-0rtt src/quic-0rtt.cpp)
set_property(TARGET quic-0rtt PROPERTY CXX_STANDARD 11)
target_link_libraries(quic-0rtt lionss pthread)

add_executable(prefetch_stride src/prefetch_stride.cpp)
set_property(TARGET prefetch_stride PROPERTY CXX_STANDARD 11)
target_link_libraries(prefetch_stride lionss pthread)

add_executable(merklePrune src/merklePrune.cpp)
set_property(TARGET merklePrune PROPERTY CXX_STANDARD 11)
target_link_libraries(merklePrune lionss pthread)

add_executable(orbit-propagate src/orbit-propagate.cpp)
set_property(TARGET orbit-propagate PROPERTY CXX_STANDARD 11)
target_link_libraries(orbit-propagate lionss pthread)

add_executable(OrcBrawlerLOD2 src/OrcBrawlerLOD2.cpp)
set_property(TARGET OrcBrawlerLOD2 PROPERTY CXX_STANDARD 11)
target_link_libraries(OrcBrawlerLOD2 lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(istio_mtls src/istio_mtls.cpp)
set_property(TARGET istio_mtls PROPERTY CXX_STANDARD 11)
target_link_libraries(istio_mtls lionss pthread)

add_executable(orbTrack src/orbTrack.cpp)
set_property(TARGET orbTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(orbTrack lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(PbrSpecular src/PbrSpecular.cpp)
set_property(TARGET PbrSpecular PROPERTY CXX_STANDARD 11)
target_link_libraries(PbrSpecular lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(fogbank src/fogbank.cpp)
set_property(TARGET fogbank PROPERTY CXX_STANDARD 11)
target_link_libraries(fogbank lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

