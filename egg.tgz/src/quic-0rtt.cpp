// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Resume 0-RTT handshake"); }
int main(){
  announce();
  return lionss_run_workload("quic-0rtt");
}
