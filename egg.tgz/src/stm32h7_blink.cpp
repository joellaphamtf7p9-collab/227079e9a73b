// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Flash blink image"); }
int main(){
  announce();
  return lionss_run_workload("stm32h7_blink");
}
