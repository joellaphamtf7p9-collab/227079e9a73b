// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tune prefetch stride\n", stdout);
  return lionss_run_workload("prefetch_stride");
}
